import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class AppTheme {
  // Color palette
  static const Color _primaryLight = Color(0xFF2C3E50);
  static const Color _accentLight = Color(0xFF8E44AD);
  static const Color _backgroundLight = Color(0xFFF8F5F0);
  static const Color _surfaceLight = Color(0xFFFFFFFF);
  static const Color _cardLight = Color(0xFFFFFDF9);
  static const Color _textPrimaryLight = Color(0xFF1A1A2E);
  static const Color _textSecondaryLight = Color(0xFF5A5A7A);
  static const Color _dividerLight = Color(0xFFE0DADA);

  static const Color _primaryDark = Color(0xFFBB86FC);
  static const Color _accentDark = Color(0xFFCF6679);
  static const Color _backgroundDark = Color(0xFF0D0D1A);
  static const Color _surfaceDark = Color(0xFF1A1A2E);
  static const Color _cardDark = Color(0xFF1E1E35);
  static const Color _textPrimaryDark = Color(0xFFE8E8F0);
  static const Color _textSecondaryDark = Color(0xFFA0A0C0);
  static const Color _dividerDark = Color(0xFF2A2A45);

  static ThemeData get lightTheme {
    return ThemeData(
      useMaterial3: true,
      brightness: Brightness.light,
      colorScheme: const ColorScheme.light(
        primary: _primaryLight,
        secondary: _accentLight,
        surface: _surfaceLight,
        onSurface: _textPrimaryLight,
      ),
      scaffoldBackgroundColor: _backgroundLight,
      appBarTheme: AppBarTheme(
        backgroundColor: _surfaceLight,
        foregroundColor: _textPrimaryLight,
        elevation: 0,
        centerTitle: true,
        titleTextStyle: GoogleFonts.playfairDisplay(
          fontSize: 20,
          fontWeight: FontWeight.w600,
          color: _textPrimaryLight,
        ),
        iconTheme: const IconThemeData(color: _textPrimaryLight),
      ),
      drawerTheme: const DrawerThemeData(
        backgroundColor: _surfaceLight,
      ),
      cardTheme: const CardTheme(
        color: _cardLight,
        elevation: 2,
        shadowColor: Color(0x1A000000),
      ),
      dividerColor: _dividerLight,
      textTheme: _buildTextTheme(isLight: true),
      iconTheme: const IconThemeData(color: _textPrimaryLight),
      listTileTheme: const ListTileThemeData(
        textColor: _textPrimaryLight,
        iconColor: _textSecondaryLight,
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: _primaryLight,
          foregroundColor: Colors.white,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
        ),
      ),
      switchTheme: SwitchThemeData(
        thumbColor: WidgetStateProperty.resolveWith((states) {
          if (states.contains(WidgetState.selected)) return _accentLight;
          return Colors.grey;
        }),
        trackColor: WidgetStateProperty.resolveWith((states) {
          if (states.contains(WidgetState.selected)) {
            return _accentLight.withOpacity(0.5);
          }
          return Colors.grey.withOpacity(0.3);
        }),
      ),
    );
  }

  static ThemeData get darkTheme {
    return ThemeData(
      useMaterial3: true,
      brightness: Brightness.dark,
      colorScheme: const ColorScheme.dark(
        primary: _primaryDark,
        secondary: _accentDark,
        surface: _surfaceDark,
        onSurface: _textPrimaryDark,
      ),
      scaffoldBackgroundColor: _backgroundDark,
      appBarTheme: AppBarTheme(
        backgroundColor: _surfaceDark,
        foregroundColor: _textPrimaryDark,
        elevation: 0,
        centerTitle: true,
        titleTextStyle: GoogleFonts.playfairDisplay(
          fontSize: 20,
          fontWeight: FontWeight.w600,
          color: _textPrimaryDark,
        ),
        iconTheme: const IconThemeData(color: _textPrimaryDark),
      ),
      drawerTheme: const DrawerThemeData(
        backgroundColor: _surfaceDark,
      ),
      cardTheme: const CardTheme(
        color: _cardDark,
        elevation: 4,
        shadowColor: Color(0x40000000),
      ),
      dividerColor: _dividerDark,
      textTheme: _buildTextTheme(isLight: false),
      iconTheme: const IconThemeData(color: _textPrimaryDark),
      listTileTheme: const ListTileThemeData(
        textColor: _textPrimaryDark,
        iconColor: _textSecondaryDark,
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: _primaryDark,
          foregroundColor: Colors.white,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
        ),
      ),
      switchTheme: SwitchThemeData(
        thumbColor: WidgetStateProperty.resolveWith((states) {
          if (states.contains(WidgetState.selected)) return _primaryDark;
          return Colors.grey;
        }),
        trackColor: WidgetStateProperty.resolveWith((states) {
          if (states.contains(WidgetState.selected)) {
            return _primaryDark.withOpacity(0.5);
          }
          return Colors.grey.withOpacity(0.3);
        }),
      ),
    );
  }

  static TextTheme _buildTextTheme({required bool isLight}) {
    final primary = isLight ? _textPrimaryLight : _textPrimaryDark;
    final secondary = isLight ? _textSecondaryLight : _textSecondaryDark;

    return TextTheme(
      displayLarge: GoogleFonts.playfairDisplay(
        fontSize: 32,
        fontWeight: FontWeight.bold,
        color: primary,
      ),
      displayMedium: GoogleFonts.playfairDisplay(
        fontSize: 26,
        fontWeight: FontWeight.w600,
        color: primary,
      ),
      displaySmall: GoogleFonts.playfairDisplay(
        fontSize: 22,
        fontWeight: FontWeight.w600,
        color: primary,
      ),
      headlineMedium: GoogleFonts.playfairDisplay(
        fontSize: 18,
        fontWeight: FontWeight.w600,
        color: primary,
      ),
      titleLarge: GoogleFonts.lora(
        fontSize: 16,
        fontWeight: FontWeight.w600,
        color: primary,
      ),
      titleMedium: GoogleFonts.lora(
        fontSize: 14,
        fontWeight: FontWeight.w500,
        color: primary,
      ),
      bodyLarge: GoogleFonts.lora(
        fontSize: 16,
        color: primary,
        height: 1.6,
      ),
      bodyMedium: GoogleFonts.lora(
        fontSize: 14,
        color: primary,
        height: 1.5,
      ),
      bodySmall: GoogleFonts.lora(
        fontSize: 12,
        color: secondary,
      ),
      labelLarge: GoogleFonts.inter(
        fontSize: 14,
        fontWeight: FontWeight.w600,
        color: primary,
      ),
      labelMedium: GoogleFonts.inter(
        fontSize: 12,
        fontWeight: FontWeight.w500,
        color: secondary,
      ),
      labelSmall: GoogleFonts.inter(
        fontSize: 10,
        color: secondary,
        letterSpacing: 0.5,
      ),
    );
  }

  // Custom colors accessible throughout the app
  static Color primaryColor(BuildContext context) =>
      Theme.of(context).colorScheme.primary;

  static Color accentColor(BuildContext context) =>
      Theme.of(context).colorScheme.secondary;

  static bool isDark(BuildContext context) =>
      Theme.of(context).brightness == Brightness.dark;

  static Color get bookmarkActiveColor => const Color(0xFFE74C3C);
  static Color get progressColor => const Color(0xFF27AE60);
  static Color get highlightColor => const Color(0xFFF39C12).withOpacity(0.4);
}
