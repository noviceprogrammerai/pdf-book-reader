import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:flutter_animate/flutter_animate.dart';
import '../services/storage_service.dart';
import '../theme/app_theme.dart';
import 'reader_screen.dart';
import 'bookmarks_screen.dart';
import 'settings_screen.dart';

enum NavSection { reader, bookmarks, settings }

class HomeScreen extends StatefulWidget {
  final StorageService storageService;
  final Function(bool) onThemeToggle;
  final bool isDarkMode;

  const HomeScreen({
    super.key,
    required this.storageService,
    required this.onThemeToggle,
    required this.isDarkMode,
  });

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  NavSection _currentSection = NavSection.reader;
  int _currentPage = 0;
  int _totalPages = 0;
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _currentPage = widget.storageService.getLastPage();
    _totalPages = widget.storageService.getTotalPages();
  }

  void _onPageChanged(int page, int total) {
    setState(() {
      _currentPage = page;
      _totalPages = total;
    });
  }

  void _navigateTo(NavSection section) {
    setState(() => _currentSection = section);
    Navigator.pop(context); // Close drawer
  }

  void _jumpToPage(int page) {
    setState(() {
      _currentSection = NavSection.reader;
      _currentPage = page;
    });
  }

  @override
  Widget build(BuildContext context) {
    final isDark = AppTheme.isDark(context);
    final theme = Theme.of(context);

    return Scaffold(
      key: _scaffoldKey,
      drawer: _buildDrawer(isDark, theme),
      body: _buildBody(),
    );
  }

  Widget _buildBody() {
    switch (_currentSection) {
      case NavSection.reader:
        return ReaderScreen(
          storageService: widget.storageService,
          initialPage: _currentPage,
          onPageChanged: _onPageChanged,
          onOpenDrawer: () => _scaffoldKey.currentState?.openDrawer(),
        );
      case NavSection.bookmarks:
        return BookmarksScreen(
          storageService: widget.storageService,
          onJumpToPage: _jumpToPage,
          onOpenDrawer: () => _scaffoldKey.currentState?.openDrawer(),
        );
      case NavSection.settings:
        return SettingsScreen(
          storageService: widget.storageService,
          isDarkMode: widget.isDarkMode,
          onThemeToggle: widget.onThemeToggle,
          onOpenDrawer: () => _scaffoldKey.currentState?.openDrawer(),
        );
    }
  }

  Widget _buildDrawer(bool isDark, ThemeData theme) {
    final progress = _totalPages > 0 ? _currentPage / _totalPages : 0.0;
    final accentColor = isDark ? const Color(0xFFBB86FC) : const Color(0xFF8E44AD);
    final bgColor = isDark ? const Color(0xFF1A1A2E) : Colors.white;
    final textColor = isDark ? const Color(0xFFE8E8F0) : const Color(0xFF1A1A2E);
    final subtextColor = isDark ? const Color(0xFFA0A0C0) : const Color(0xFF5A5A7A);

    return Drawer(
      backgroundColor: bgColor,
      child: Column(
        children: [
          // Header
          Container(
            width: double.infinity,
            padding: const EdgeInsets.fromLTRB(24, 60, 24, 28),
            decoration: BoxDecoration(
              color: accentColor.withOpacity(0.08),
              border: Border(
                bottom: BorderSide(
                  color: accentColor.withOpacity(0.15),
                  width: 1,
                ),
              ),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  width: 52,
                  height: 52,
                  decoration: BoxDecoration(
                    color: accentColor.withOpacity(0.15),
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(
                      color: accentColor.withOpacity(0.3),
                      width: 1.5,
                    ),
                  ),
                  child: Icon(
                    Icons.menu_book_rounded,
                    color: accentColor,
                    size: 28,
                  ),
                ),
                const SizedBox(height: 16),
                Text(
                  'The Art of\nDeep Focus',
                  style: GoogleFonts.playfairDisplay(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                    color: textColor,
                    height: 1.3,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  'By A. Digital Author',
                  style: GoogleFonts.lora(
                    fontSize: 13,
                    color: subtextColor,
                    fontStyle: FontStyle.italic,
                  ),
                ),
                const SizedBox(height: 16),
                // Progress bar
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          'Reading progress',
                          style: GoogleFonts.inter(
                            fontSize: 11,
                            color: subtextColor,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                        Text(
                          _totalPages > 0
                              ? '${(progress * 100).toStringAsFixed(0)}%'
                              : '—',
                          style: GoogleFonts.inter(
                            fontSize: 11,
                            color: accentColor,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 6),
                    ClipRRect(
                      borderRadius: BorderRadius.circular(4),
                      child: LinearProgressIndicator(
                        value: progress,
                        backgroundColor: accentColor.withOpacity(0.15),
                        valueColor: AlwaysStoppedAnimation<Color>(accentColor),
                        minHeight: 6,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      _totalPages > 0
                          ? 'Page $_currentPage of $_totalPages'
                          : 'Not started yet',
                      style: GoogleFonts.inter(
                        fontSize: 11,
                        color: subtextColor,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),

          // Nav items
          const SizedBox(height: 12),
          _DrawerNavItem(
            icon: Icons.auto_stories_outlined,
            activeIcon: Icons.auto_stories,
            label: 'Read Book',
            isActive: _currentSection == NavSection.reader,
            accentColor: accentColor,
            textColor: textColor,
            onTap: () => _navigateTo(NavSection.reader),
          ).animate().fadeIn(delay: 50.ms).slideX(begin: -0.1, end: 0, delay: 50.ms),

          _DrawerNavItem(
            icon: Icons.bookmark_border_rounded,
            activeIcon: Icons.bookmark_rounded,
            label: 'Bookmarks',
            isActive: _currentSection == NavSection.bookmarks,
            accentColor: accentColor,
            textColor: textColor,
            onTap: () => _navigateTo(NavSection.bookmarks),
            badge: widget.storageService.getBookmarks().length,
          ).animate().fadeIn(delay: 100.ms).slideX(begin: -0.1, end: 0, delay: 100.ms),

          _DrawerNavItem(
            icon: Icons.tune_outlined,
            activeIcon: Icons.tune,
            label: 'Settings',
            isActive: _currentSection == NavSection.settings,
            accentColor: accentColor,
            textColor: textColor,
            onTap: () => _navigateTo(NavSection.settings),
          ).animate().fadeIn(delay: 150.ms).slideX(begin: -0.1, end: 0, delay: 150.ms),

          const Spacer(),

          // Footer
          Padding(
            padding: const EdgeInsets.all(20),
            child: Text(
              'PDF Reader v1.0',
              style: GoogleFonts.inter(
                fontSize: 11,
                color: subtextColor.withOpacity(0.5),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _DrawerNavItem extends StatelessWidget {
  final IconData icon;
  final IconData activeIcon;
  final String label;
  final bool isActive;
  final Color accentColor;
  final Color textColor;
  final VoidCallback onTap;
  final int? badge;

  const _DrawerNavItem({
    required this.icon,
    required this.activeIcon,
    required this.label,
    required this.isActive,
    required this.accentColor,
    required this.textColor,
    required this.onTap,
    this.badge,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 2),
      child: Material(
        color: Colors.transparent,
        borderRadius: BorderRadius.circular(12),
        child: InkWell(
          borderRadius: BorderRadius.circular(12),
          onTap: onTap,
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 200),
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 13),
            decoration: BoxDecoration(
              color: isActive ? accentColor.withOpacity(0.12) : Colors.transparent,
              borderRadius: BorderRadius.circular(12),
              border: isActive
                  ? Border.all(color: accentColor.withOpacity(0.2), width: 1)
                  : null,
            ),
            child: Row(
              children: [
                Icon(
                  isActive ? activeIcon : icon,
                  color: isActive ? accentColor : textColor.withOpacity(0.5),
                  size: 22,
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Text(
                    label,
                    style: GoogleFonts.inter(
                      fontSize: 15,
                      fontWeight: isActive ? FontWeight.w600 : FontWeight.w400,
                      color: isActive ? accentColor : textColor.withOpacity(0.7),
                    ),
                  ),
                ),
                if (badge != null && badge! > 0)
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                    decoration: BoxDecoration(
                      color: accentColor.withOpacity(0.15),
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Text(
                      '$badge',
                      style: GoogleFonts.inter(
                        fontSize: 11,
                        fontWeight: FontWeight.w600,
                        color: accentColor,
                      ),
                    ),
                  ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
