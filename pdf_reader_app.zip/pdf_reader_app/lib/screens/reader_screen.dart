import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:syncfusion_flutter_pdfviewer/pdfviewer.dart';
import '../services/storage_service.dart';
import '../theme/app_theme.dart';
import '../models/bookmark.dart';
import '../widgets/search_dialog.dart';
import '../widgets/page_jump_dialog.dart';

class ReaderScreen extends StatefulWidget {
  final StorageService storageService;
  final int initialPage;
  final Function(int page, int total) onPageChanged;
  final VoidCallback onOpenDrawer;

  const ReaderScreen({
    super.key,
    required this.storageService,
    required this.initialPage,
    required this.onPageChanged,
    required this.onOpenDrawer,
  });

  @override
  State<ReaderScreen> createState() => _ReaderScreenState();
}

class _ReaderScreenState extends State<ReaderScreen> {
  late PdfViewerController _pdfController;
  final GlobalKey<SfPdfViewerState> _pdfViewerKey = GlobalKey();

  int _currentPage = 0;
  int _totalPages = 0;
  bool _isBookmarked = false;
  bool _showControls = true;
  bool _isLoaded = false;

  // Layout mode
  PdfPageLayoutMode _layoutMode = PdfPageLayoutMode.continuous;
  PdfScrollDirection _scrollDirection = PdfScrollDirection.vertical;

  @override
  void initState() {
    super.initState();
    _pdfController = PdfViewerController();
    _currentPage = widget.initialPage > 0 ? widget.initialPage : 1;
    _isBookmarked = widget.storageService.isPageBookmarked(_currentPage);
  }

  @override
  void dispose() {
    _pdfController.dispose();
    super.dispose();
  }

  void _onDocumentLoaded(PdfDocumentLoadedDetails details) {
    final total = details.document.pages.count;
    setState(() {
      _totalPages = total;
      _isLoaded = true;
    });
    widget.storageService.saveTotalPages(total);
    widget.onPageChanged(_currentPage, total);

    // Jump to saved page
    if (_currentPage > 1 && _currentPage <= total) {
      Future.delayed(const Duration(milliseconds: 300), () {
        if (mounted) {
          _pdfController.jumpToPage(_currentPage);
        }
      });
    }
  }

  void _onPageChanged(PdfPageChangedDetails details) {
    final page = details.newPageNumber;
    setState(() {
      _currentPage = page;
      _isBookmarked = widget.storageService.isPageBookmarked(page);
    });
    widget.storageService.saveLastPage(page);
    widget.onPageChanged(page, _totalPages);
  }

  void _toggleBookmark() async {
    final pageTitle = 'Page $_currentPage';
    await widget.storageService.toggleBookmark(_currentPage, pageTitle);
    setState(() {
      _isBookmarked = widget.storageService.isPageBookmarked(_currentPage);
    });

    if (mounted) {
      ScaffoldMessenger.of(context).clearSnackBars();
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            _isBookmarked ? 'Bookmark added' : 'Bookmark removed',
            style: GoogleFonts.inter(fontSize: 14),
          ),
          behavior: SnackBarBehavior.floating,
          duration: const Duration(seconds: 2),
          backgroundColor: _isBookmarked
              ? AppTheme.bookmarkActiveColor
              : Colors.grey[700],
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
          margin: const EdgeInsets.all(16),
        ),
      );
    }
  }

  void _toggleControls() {
    setState(() => _showControls = !_showControls);
    if (_showControls) {
      SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
    } else {
      SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
    }
  }

  void _openSearch() {
    showDialog(
      context: context,
      builder: (_) => SearchDialog(pdfViewerKey: _pdfViewerKey),
    );
  }

  void _openPageJump() {
    showDialog(
      context: context,
      builder: (_) => PageJumpDialog(
        currentPage: _currentPage,
        totalPages: _totalPages,
        onJump: (page) => _pdfController.jumpToPage(page),
      ),
    );
  }

  void _toggleLayout() {
    setState(() {
      if (_layoutMode == PdfPageLayoutMode.continuous) {
        _layoutMode = PdfPageLayoutMode.single;
        _scrollDirection = PdfScrollDirection.horizontal;
      } else {
        _layoutMode = PdfPageLayoutMode.continuous;
        _scrollDirection = PdfScrollDirection.vertical;
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final isDark = AppTheme.isDark(context);
    final theme = Theme.of(context);
    final appBarBg = isDark ? const Color(0xFF1A1A2E) : Colors.white;
    final appBarFg = isDark ? const Color(0xFFE8E8F0) : const Color(0xFF1A1A2E);
    final accentColor = isDark ? const Color(0xFFBB86FC) : const Color(0xFF8E44AD);

    return Scaffold(
      backgroundColor: isDark ? const Color(0xFF0D0D1A) : const Color(0xFFF0EDE8),
      body: Stack(
        children: [
          // PDF Viewer
          GestureDetector(
            onTap: _toggleControls,
            child: SfPdfViewer.asset(
              'assets/pdf/book.pdf',
              key: _pdfViewerKey,
              controller: _pdfController,
              pageLayoutMode: _layoutMode,
              scrollDirection: _scrollDirection,
              onDocumentLoaded: _onDocumentLoaded,
              onPageChanged: _onPageChanged,
              enableDoubleTapZooming: true,
              enableTextSelection: true,
              canShowScrollHead: true,
              canShowScrollStatus: true,
              canShowPaginationDialog: false,
              pageSpacing: 8,
              interactionMode: PdfInteractionMode.selection,
            ),
          ),

          // Top App Bar (animated)
          AnimatedPositioned(
            duration: const Duration(milliseconds: 250),
            curve: Curves.easeInOut,
            top: _showControls ? 0 : -120,
            left: 0,
            right: 0,
            child: Container(
              decoration: BoxDecoration(
                color: appBarBg,
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(isDark ? 0.3 : 0.08),
                    blurRadius: 12,
                    offset: const Offset(0, 2),
                  ),
                ],
              ),
              child: SafeArea(
                bottom: false,
                child: SizedBox(
                  height: 56,
                  child: Row(
                    children: [
                      IconButton(
                        onPressed: widget.onOpenDrawer,
                        icon: Icon(Icons.menu_rounded, color: appBarFg),
                        tooltip: 'Menu',
                      ),
                      const SizedBox(width: 4),
                      Expanded(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'The Art of Deep Focus',
                              style: GoogleFonts.playfairDisplay(
                                fontSize: 15,
                                fontWeight: FontWeight.w600,
                                color: appBarFg,
                              ),
                              overflow: TextOverflow.ellipsis,
                            ),
                            if (_totalPages > 0)
                              Text(
                                'Page $_currentPage of $_totalPages',
                                style: GoogleFonts.inter(
                                  fontSize: 11,
                                  color: appBarFg.withOpacity(0.5),
                                ),
                              ),
                          ],
                        ),
                      ),
                      IconButton(
                        onPressed: _openSearch,
                        icon: Icon(Icons.search_rounded, color: appBarFg),
                        tooltip: 'Search',
                      ),
                      IconButton(
                        onPressed: _toggleBookmark,
                        icon: Icon(
                          _isBookmarked
                              ? Icons.bookmark_rounded
                              : Icons.bookmark_border_rounded,
                          color: _isBookmarked
                              ? AppTheme.bookmarkActiveColor
                              : appBarFg,
                        ),
                        tooltip: _isBookmarked ? 'Remove bookmark' : 'Add bookmark',
                      ),
                      IconButton(
                        onPressed: _toggleLayout,
                        icon: Icon(
                          _layoutMode == PdfPageLayoutMode.continuous
                              ? Icons.swap_horiz_rounded
                              : Icons.swap_vert_rounded,
                          color: appBarFg,
                        ),
                        tooltip: 'Toggle scroll direction',
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),

          // Bottom bar
          AnimatedPositioned(
            duration: const Duration(milliseconds: 250),
            curve: Curves.easeInOut,
            bottom: _showControls ? 0 : -120,
            left: 0,
            right: 0,
            child: Container(
              decoration: BoxDecoration(
                color: appBarBg,
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(isDark ? 0.3 : 0.08),
                    blurRadius: 12,
                    offset: const Offset(0, -2),
                  ),
                ],
              ),
              child: SafeArea(
                top: false,
                child: Padding(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 20,
                    vertical: 10,
                  ),
                  child: Row(
                    children: [
                      // Prev page
                      _NavButton(
                        icon: Icons.chevron_left_rounded,
                        onTap: _currentPage > 1
                            ? () => _pdfController.previousPage()
                            : null,
                        color: appBarFg,
                      ),
                      const SizedBox(width: 12),

                      // Progress slider
                      Expanded(
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            if (_totalPages > 0)
                              SliderTheme(
                                data: SliderThemeData(
                                  trackHeight: 3,
                                  thumbRadius: 7,
                                  activeTrackColor: accentColor,
                                  inactiveTrackColor:
                                      accentColor.withOpacity(0.2),
                                  thumbColor: accentColor,
                                  overlayRadius: 14,
                                  overlayColor: accentColor.withOpacity(0.15),
                                ),
                                child: Slider(
                                  value: _currentPage.toDouble(),
                                  min: 1,
                                  max: _totalPages.toDouble(),
                                  onChanged: (value) {
                                    _pdfController
                                        .jumpToPage(value.round());
                                  },
                                ),
                              ),
                            GestureDetector(
                              onTap: _openPageJump,
                              child: Text(
                                _totalPages > 0
                                    ? '${((_currentPage / _totalPages) * 100).toStringAsFixed(0)}% complete'
                                    : 'Loading...',
                                style: GoogleFonts.inter(
                                  fontSize: 11,
                                  color: appBarFg.withOpacity(0.5),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),

                      const SizedBox(width: 12),

                      // Next page
                      _NavButton(
                        icon: Icons.chevron_right_rounded,
                        onTap: _currentPage < _totalPages
                            ? () => _pdfController.nextPage()
                            : null,
                        color: appBarFg,
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),

          // Loading overlay
          if (!_isLoaded)
            Container(
              color: isDark ? const Color(0xFF0D0D1A) : const Color(0xFFF8F5F0),
              child: Center(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(
                      Icons.menu_book_rounded,
                      size: 48,
                      color: accentColor.withOpacity(0.5),
                    ),
                    const SizedBox(height: 20),
                    CircularProgressIndicator(
                      color: accentColor,
                      strokeWidth: 2.5,
                    ),
                    const SizedBox(height: 16),
                    Text(
                      'Opening your book...',
                      style: GoogleFonts.lora(
                        fontSize: 14,
                        color: isDark
                            ? const Color(0xFFA0A0C0)
                            : const Color(0xFF5A5A7A),
                        fontStyle: FontStyle.italic,
                      ),
                    ),
                  ],
                ),
              ),
            ),
        ],
      ),
    );
  }
}

class _NavButton extends StatelessWidget {
  final IconData icon;
  final VoidCallback? onTap;
  final Color color;

  const _NavButton({
    required this.icon,
    required this.onTap,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 38,
        height: 38,
        decoration: BoxDecoration(
          color: color.withOpacity(0.06),
          borderRadius: BorderRadius.circular(10),
        ),
        child: Icon(
          icon,
          color: onTap != null ? color : color.withOpacity(0.25),
          size: 22,
        ),
      ),
    );
  }
}
