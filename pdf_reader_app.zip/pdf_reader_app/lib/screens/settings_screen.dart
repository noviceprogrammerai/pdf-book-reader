import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:flutter_animate/flutter_animate.dart';
import '../services/storage_service.dart';
import '../theme/app_theme.dart';

class SettingsScreen extends StatefulWidget {
  final StorageService storageService;
  final bool isDarkMode;
  final Function(bool) onThemeToggle;
  final VoidCallback onOpenDrawer;

  const SettingsScreen({
    super.key,
    required this.storageService,
    required this.isDarkMode,
    required this.onThemeToggle,
    required this.onOpenDrawer,
  });

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  late bool _isDark;
  late double _fontScale;
  int _lastPage = 0;
  int _totalPages = 0;
  int _bookmarkCount = 0;

  @override
  void initState() {
    super.initState();
    _isDark = widget.isDarkMode;
    _fontScale = widget.storageService.getFontScale();
    _refreshStats();
  }

  void _refreshStats() {
    setState(() {
      _lastPage = widget.storageService.getLastPage();
      _totalPages = widget.storageService.getTotalPages();
      _bookmarkCount = widget.storageService.getBookmarks().length;
    });
  }

  Future<void> _resetProgress() async {
    final confirmed = await _showConfirmDialog(
      'Reset Reading Progress',
      'This will reset your reading position to page 1. Are you sure?',
    );
    if (confirmed) {
      await widget.storageService.resetProgress();
      _refreshStats();
      if (mounted) _showSnack('Reading progress reset');
    }
  }

  Future<void> _clearBookmarks() async {
    final confirmed = await _showConfirmDialog(
      'Clear All Bookmarks',
      'All saved bookmarks will be permanently removed.',
    );
    if (confirmed) {
      await widget.storageService.clearAllBookmarks();
      _refreshStats();
      if (mounted) _showSnack('All bookmarks cleared');
    }
  }

  Future<void> _resetAll() async {
    final confirmed = await _showConfirmDialog(
      'Reset Everything',
      'This will clear all reading progress and bookmarks. This cannot be undone.',
      isDangerous: true,
    );
    if (confirmed) {
      await widget.storageService.resetAll();
      _refreshStats();
      if (mounted) _showSnack('All data cleared');
    }
  }

  Future<bool> _showConfirmDialog(String title, String content,
      {bool isDangerous = false}) async {
    final result = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: Text(title,
            style: GoogleFonts.playfairDisplay(fontWeight: FontWeight.bold, fontSize: 18)),
        content: Text(content, style: GoogleFonts.lora(fontSize: 14)),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: Text('Cancel', style: GoogleFonts.inter()),
          ),
          TextButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: Text(
              'Confirm',
              style: GoogleFonts.inter(
                color: isDangerous ? Colors.red : AppTheme.bookmarkActiveColor,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
        ],
      ),
    );
    return result ?? false;
  }

  void _showSnack(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(msg, style: GoogleFonts.inter(fontSize: 14)),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
        margin: const EdgeInsets.all(16),
        duration: const Duration(seconds: 2),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final isDark = AppTheme.isDark(context);
    final appBarBg = isDark ? const Color(0xFF1A1A2E) : Colors.white;
    final fg = isDark ? const Color(0xFFE8E8F0) : const Color(0xFF1A1A2E);
    final subtextColor = isDark ? const Color(0xFFA0A0C0) : const Color(0xFF5A5A7A);
    final accentColor = isDark ? const Color(0xFFBB86FC) : const Color(0xFF8E44AD);
    final cardBg = isDark ? const Color(0xFF1E1E35) : Colors.white;
    final sectionBg = isDark ? const Color(0xFF0D0D1A) : const Color(0xFFF8F5F0);

    double progress = _totalPages > 0 ? _lastPage / _totalPages : 0.0;

    return Scaffold(
      backgroundColor: sectionBg,
      appBar: AppBar(
        backgroundColor: appBarBg,
        leading: IconButton(
          icon: Icon(Icons.menu_rounded, color: fg),
          onPressed: widget.onOpenDrawer,
        ),
        title: Text(
          'Settings',
          style: GoogleFonts.playfairDisplay(
            fontSize: 20,
            fontWeight: FontWeight.w700,
            color: fg,
          ),
        ),
        elevation: 0,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Reading Stats Card
            _buildSectionLabel('Reading Stats', fg, subtextColor),
            _buildCard(
              isDark: isDark,
              cardBg: cardBg,
              accentColor: accentColor,
              child: Column(
                children: [
                  _buildStatRow(
                    icon: Icons.auto_stories_rounded,
                    label: 'Current Page',
                    value: _lastPage > 0 ? 'Page $_lastPage' : 'Not started',
                    fg: fg,
                    subtextColor: subtextColor,
                    accentColor: accentColor,
                  ),
                  _buildDivider(isDark),
                  _buildStatRow(
                    icon: Icons.bar_chart_rounded,
                    label: 'Progress',
                    value: _totalPages > 0
                        ? '${(progress * 100).toStringAsFixed(1)}%'
                        : '—',
                    fg: fg,
                    subtextColor: subtextColor,
                    accentColor: accentColor,
                  ),
                  if (_totalPages > 0) ...[
                    const SizedBox(height: 8),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 4),
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(4),
                        child: LinearProgressIndicator(
                          value: progress,
                          backgroundColor: accentColor.withOpacity(0.15),
                          valueColor: AlwaysStoppedAnimation<Color>(accentColor),
                          minHeight: 6,
                        ),
                      ),
                    ),
                    const SizedBox(height: 8),
                  ],
                  _buildDivider(isDark),
                  _buildStatRow(
                    icon: Icons.bookmark_rounded,
                    label: 'Bookmarks',
                    value: '$_bookmarkCount saved',
                    fg: fg,
                    subtextColor: subtextColor,
                    accentColor: AppTheme.bookmarkActiveColor,
                  ),
                ],
              ),
            ).animate().fadeIn(delay: 50.ms).slideY(begin: 0.05, end: 0, delay: 50.ms),

            const SizedBox(height: 24),

            // Appearance
            _buildSectionLabel('Appearance', fg, subtextColor),
            _buildCard(
              isDark: isDark,
              cardBg: cardBg,
              accentColor: accentColor,
              child: Column(
                children: [
                  _buildToggleRow(
                    icon: isDark ? Icons.dark_mode_rounded : Icons.light_mode_rounded,
                    label: 'Dark Mode',
                    value: _isDark,
                    fg: fg,
                    subtextColor: subtextColor,
                    accentColor: accentColor,
                    onChanged: (val) {
                      setState(() => _isDark = val);
                      widget.onThemeToggle(val);
                    },
                  ),
                ],
              ),
            ).animate().fadeIn(delay: 100.ms).slideY(begin: 0.05, end: 0, delay: 100.ms),

            const SizedBox(height: 24),

            // Data Management
            _buildSectionLabel('Data Management', fg, subtextColor),
            _buildCard(
              isDark: isDark,
              cardBg: cardBg,
              accentColor: accentColor,
              child: Column(
                children: [
                  _buildActionRow(
                    icon: Icons.replay_rounded,
                    label: 'Reset Reading Progress',
                    subtitle: 'Go back to page 1',
                    fg: fg,
                    subtextColor: subtextColor,
                    iconColor: Colors.orange,
                    onTap: _resetProgress,
                  ),
                  _buildDivider(isDark),
                  _buildActionRow(
                    icon: Icons.bookmark_remove_rounded,
                    label: 'Clear All Bookmarks',
                    subtitle: 'Remove $_bookmarkCount saved bookmarks',
                    fg: fg,
                    subtextColor: subtextColor,
                    iconColor: AppTheme.bookmarkActiveColor,
                    onTap: _clearBookmarks,
                  ),
                  _buildDivider(isDark),
                  _buildActionRow(
                    icon: Icons.delete_forever_rounded,
                    label: 'Reset Everything',
                    subtitle: 'Clear all progress and bookmarks',
                    fg: fg,
                    subtextColor: subtextColor,
                    iconColor: Colors.red,
                    onTap: _resetAll,
                  ),
                ],
              ),
            ).animate().fadeIn(delay: 150.ms).slideY(begin: 0.05, end: 0, delay: 150.ms),

            const SizedBox(height: 24),

            // About
            _buildSectionLabel('About', fg, subtextColor),
            _buildCard(
              isDark: isDark,
              cardBg: cardBg,
              accentColor: accentColor,
              child: Column(
                children: [
                  _buildInfoRow('Book', 'The Art of Deep Focus', fg, subtextColor),
                  _buildDivider(isDark),
                  _buildInfoRow('Author', 'A. Digital Author', fg, subtextColor),
                  _buildDivider(isDark),
                  _buildInfoRow('App Version', '1.0.0', fg, subtextColor),
                  _buildDivider(isDark),
                  _buildInfoRow('Storage', 'Offline — all data local', fg, subtextColor),
                ],
              ),
            ).animate().fadeIn(delay: 200.ms).slideY(begin: 0.05, end: 0, delay: 200.ms),

            const SizedBox(height: 40),

            Center(
              child: Text(
                'PDF Reader • All content stored locally',
                style: GoogleFonts.inter(
                  fontSize: 11,
                  color: subtextColor.withOpacity(0.4),
                ),
              ),
            ),
            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }

  Widget _buildSectionLabel(String label, Color fg, Color subtextColor) {
    return Padding(
      padding: const EdgeInsets.only(left: 4, bottom: 8),
      child: Text(
        label.toUpperCase(),
        style: GoogleFonts.inter(
          fontSize: 11,
          fontWeight: FontWeight.w700,
          color: subtextColor,
          letterSpacing: 1.2,
        ),
      ),
    );
  }

  Widget _buildCard({
    required bool isDark,
    required Color cardBg,
    required Color accentColor,
    required Widget child,
  }) {
    return Container(
      width: double.infinity,
      decoration: BoxDecoration(
        color: cardBg,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: accentColor.withOpacity(0.08), width: 1),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(isDark ? 0.2 : 0.05),
            blurRadius: 10,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Padding(padding: const EdgeInsets.symmetric(vertical: 4), child: child),
    );
  }

  Widget _buildDivider(bool isDark) {
    return Divider(
      height: 1,
      thickness: 1,
      indent: 16,
      endIndent: 16,
      color: isDark ? const Color(0xFF2A2A45) : const Color(0xFFF0EDE8),
    );
  }

  Widget _buildStatRow({
    required IconData icon,
    required String label,
    required String value,
    required Color fg,
    required Color subtextColor,
    required Color accentColor,
  }) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      child: Row(
        children: [
          Container(
            width: 36,
            height: 36,
            decoration: BoxDecoration(
              color: accentColor.withOpacity(0.1),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Icon(icon, color: accentColor, size: 18),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Text(label,
                style: GoogleFonts.inter(fontSize: 14, color: fg, fontWeight: FontWeight.w500)),
          ),
          Text(value,
              style: GoogleFonts.inter(fontSize: 14, color: subtextColor)),
        ],
      ),
    );
  }

  Widget _buildToggleRow({
    required IconData icon,
    required String label,
    required bool value,
    required Color fg,
    required Color subtextColor,
    required Color accentColor,
    required Function(bool) onChanged,
  }) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
      child: Row(
        children: [
          Container(
            width: 36,
            height: 36,
            decoration: BoxDecoration(
              color: accentColor.withOpacity(0.1),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Icon(icon, color: accentColor, size: 18),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Text(label,
                style: GoogleFonts.inter(fontSize: 14, color: fg, fontWeight: FontWeight.w500)),
          ),
          Switch(value: value, onChanged: onChanged),
        ],
      ),
    );
  }

  Widget _buildActionRow({
    required IconData icon,
    required String label,
    required String subtitle,
    required Color fg,
    required Color subtextColor,
    required Color iconColor,
    required VoidCallback onTap,
  }) {
    return ListTile(
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
      leading: Container(
        width: 36,
        height: 36,
        decoration: BoxDecoration(
          color: iconColor.withOpacity(0.1),
          borderRadius: BorderRadius.circular(8),
        ),
        child: Icon(icon, color: iconColor, size: 18),
      ),
      title: Text(label,
          style: GoogleFonts.inter(fontSize: 14, color: fg, fontWeight: FontWeight.w500)),
      subtitle: Text(subtitle,
          style: GoogleFonts.inter(fontSize: 12, color: subtextColor)),
      trailing: Icon(Icons.chevron_right_rounded, color: subtextColor, size: 20),
      onTap: onTap,
    );
  }

  Widget _buildInfoRow(String label, String value, Color fg, Color subtextColor) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      child: Row(
        children: [
          Expanded(
            child: Text(label,
                style: GoogleFonts.inter(fontSize: 14, color: fg, fontWeight: FontWeight.w500)),
          ),
          Text(value,
              style: GoogleFonts.inter(fontSize: 13, color: subtextColor)),
        ],
      ),
    );
  }
}
