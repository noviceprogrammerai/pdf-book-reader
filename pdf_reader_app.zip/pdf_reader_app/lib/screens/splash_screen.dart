import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:flutter_animate/flutter_animate.dart';
import '../services/storage_service.dart';
import 'home_screen.dart';

class SplashScreen extends StatefulWidget {
  final StorageService storageService;
  final Function(bool) onThemeToggle;
  final bool isDarkMode;

  const SplashScreen({
    super.key,
    required this.storageService,
    required this.onThemeToggle,
    required this.isDarkMode,
  });

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    _navigateToHome();
  }

  Future<void> _navigateToHome() async {
    await Future.delayed(const Duration(milliseconds: 2400));
    if (mounted) {
      Navigator.of(context).pushReplacement(
        PageRouteBuilder(
          pageBuilder: (_, __, ___) => HomeScreen(
            storageService: widget.storageService,
            onThemeToggle: widget.onThemeToggle,
            isDarkMode: widget.isDarkMode,
          ),
          transitionDuration: const Duration(milliseconds: 600),
          transitionsBuilder: (_, animation, __, child) {
            return FadeTransition(opacity: animation, child: child);
          },
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final isDark = widget.isDarkMode;
    final bg = isDark ? const Color(0xFF0D0D1A) : const Color(0xFFF8F5F0);
    final fg = isDark ? const Color(0xFFE8E8F0) : const Color(0xFF1A1A2E);
    final accent = isDark ? const Color(0xFFBB86FC) : const Color(0xFF8E44AD);

    return Scaffold(
      backgroundColor: bg,
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            // Book icon
            Container(
              width: 100,
              height: 100,
              decoration: BoxDecoration(
                color: accent.withOpacity(0.12),
                borderRadius: BorderRadius.circular(24),
                border: Border.all(color: accent.withOpacity(0.3), width: 1.5),
              ),
              child: Icon(
                Icons.menu_book_rounded,
                size: 54,
                color: accent,
              ),
            )
                .animate()
                .fadeIn(duration: 600.ms)
                .scale(begin: const Offset(0.7, 0.7), duration: 600.ms, curve: Curves.easeOutBack),

            const SizedBox(height: 28),

            Text(
              'PDF Reader',
              style: GoogleFonts.playfairDisplay(
                fontSize: 34,
                fontWeight: FontWeight.bold,
                color: fg,
                letterSpacing: 0.5,
              ),
            )
                .animate()
                .fadeIn(delay: 300.ms, duration: 600.ms)
                .slideY(begin: 0.2, end: 0, delay: 300.ms, duration: 600.ms),

            const SizedBox(height: 8),

            Text(
              'Your personal library',
              style: GoogleFonts.lora(
                fontSize: 15,
                color: fg.withOpacity(0.5),
                fontStyle: FontStyle.italic,
              ),
            )
                .animate()
                .fadeIn(delay: 500.ms, duration: 600.ms),

            const SizedBox(height: 64),

            SizedBox(
              width: 36,
              height: 36,
              child: CircularProgressIndicator(
                color: accent,
                strokeWidth: 2.5,
              ),
            ).animate().fadeIn(delay: 700.ms, duration: 400.ms),
          ],
        ),
      ),
    );
  }
}
