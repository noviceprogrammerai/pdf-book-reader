import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:flutter_animate/flutter_animate.dart';
import '../services/storage_service.dart';
import '../models/bookmark.dart';
import '../theme/app_theme.dart';

class BookmarksScreen extends StatefulWidget {
  final StorageService storageService;
  final Function(int) onJumpToPage;
  final VoidCallback onOpenDrawer;

  const BookmarksScreen({
    super.key,
    required this.storageService,
    required this.onJumpToPage,
    required this.onOpenDrawer,
  });

  @override
  State<BookmarksScreen> createState() => _BookmarksScreenState();
}

class _BookmarksScreenState extends State<BookmarksScreen> {
  List<Bookmark> _bookmarks = [];

  @override
  void initState() {
    super.initState();
    _loadBookmarks();
  }

  void _loadBookmarks() {
    setState(() {
      _bookmarks = widget.storageService.getBookmarks();
    });
  }

  Future<void> _deleteBookmark(Bookmark bookmark) async {
    await widget.storageService.removeBookmark(bookmark.pageNumber);
    _loadBookmarks();
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Bookmark removed', style: GoogleFonts.inter(fontSize: 14)),
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
          margin: const EdgeInsets.all(16),
          duration: const Duration(seconds: 2),
        ),
      );
    }
  }

  Future<void> _clearAll() async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text('Clear All Bookmarks', style: GoogleFonts.playfairDisplay(fontWeight: FontWeight.bold)),
        content: Text('Are you sure you want to remove all bookmarks?', style: GoogleFonts.lora()),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
          TextButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: Text('Clear All', style: TextStyle(color: AppTheme.bookmarkActiveColor)),
          ),
        ],
      ),
    );
    if (confirmed == true) {
      await widget.storageService.clearAllBookmarks();
      _loadBookmarks();
    }
  }

  @override
  Widget build(BuildContext context) {
    final isDark = AppTheme.isDark(context);
    final appBarBg = isDark ? const Color(0xFF1A1A2E) : Colors.white;
    final fg = isDark ? const Color(0xFFE8E8F0) : const Color(0xFF1A1A2E);
    final accentColor = isDark ? const Color(0xFFBB86FC) : const Color(0xFF8E44AD);

    return Scaffold(
      backgroundColor: isDark ? const Color(0xFF0D0D1A) : const Color(0xFFF8F5F0),
      appBar: AppBar(
        backgroundColor: appBarBg,
        leading: IconButton(
          icon: Icon(Icons.menu_rounded, color: fg),
          onPressed: widget.onOpenDrawer,
        ),
        title: Text(
          'Bookmarks',
          style: GoogleFonts.playfairDisplay(
            fontSize: 20,
            fontWeight: FontWeight.w700,
            color: fg,
          ),
        ),
        actions: [
          if (_bookmarks.isNotEmpty)
            TextButton(
              onPressed: _clearAll,
              child: Text(
                'Clear All',
                style: GoogleFonts.inter(
                  fontSize: 13,
                  color: AppTheme.bookmarkActiveColor,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ),
        ],
        elevation: 0,
        scrolledUnderElevation: 1,
      ),
      body: _bookmarks.isEmpty
          ? _buildEmptyState(isDark, accentColor, fg)
          : _buildBookmarkList(isDark, fg, accentColor),
    );
  }

  Widget _buildEmptyState(bool isDark, Color accentColor, Color fg) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            Icons.bookmark_border_rounded,
            size: 72,
            color: accentColor.withOpacity(0.3),
          ).animate().fadeIn(duration: 600.ms).scale(begin: const Offset(0.8, 0.8)),
          const SizedBox(height: 20),
          Text(
            'No bookmarks yet',
            style: GoogleFonts.playfairDisplay(
              fontSize: 22,
              fontWeight: FontWeight.w600,
              color: fg.withOpacity(0.6),
            ),
          ).animate().fadeIn(delay: 200.ms),
          const SizedBox(height: 8),
          Text(
            'Tap the bookmark icon while reading\nto save your place.',
            textAlign: TextAlign.center,
            style: GoogleFonts.lora(
              fontSize: 14,
              color: fg.withOpacity(0.4),
              fontStyle: FontStyle.italic,
            ),
          ).animate().fadeIn(delay: 300.ms),
        ],
      ),
    );
  }

  Widget _buildBookmarkList(bool isDark, Color fg, Color accentColor) {
    final cardBg = isDark ? const Color(0xFF1E1E35) : Colors.white;
    final subtextColor = isDark ? const Color(0xFFA0A0C0) : const Color(0xFF5A5A7A);

    return ListView.builder(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      itemCount: _bookmarks.length,
      itemBuilder: (context, index) {
        final bookmark = _bookmarks[index];
        return Dismissible(
          key: Key('bookmark_${bookmark.pageNumber}'),
          direction: DismissDirection.endToStart,
          onDismissed: (_) => _deleteBookmark(bookmark),
          background: Container(
            alignment: Alignment.centerRight,
            padding: const EdgeInsets.only(right: 20),
            margin: const EdgeInsets.only(bottom: 10),
            decoration: BoxDecoration(
              color: AppTheme.bookmarkActiveColor.withOpacity(0.15),
              borderRadius: BorderRadius.circular(14),
            ),
            child: Icon(Icons.delete_outline_rounded, color: AppTheme.bookmarkActiveColor, size: 26),
          ),
          child: Container(
            margin: const EdgeInsets.only(bottom: 10),
            decoration: BoxDecoration(
              color: cardBg,
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: accentColor.withOpacity(0.1), width: 1),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(isDark ? 0.2 : 0.05),
                  blurRadius: 8,
                  offset: const Offset(0, 2),
                ),
              ],
            ),
            child: ListTile(
              contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              leading: Container(
                width: 44,
                height: 44,
                decoration: BoxDecoration(
                  color: AppTheme.bookmarkActiveColor.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Center(
                  child: Text(
                    '${bookmark.pageNumber}',
                    style: GoogleFonts.playfairDisplay(
                      fontSize: 15,
                      fontWeight: FontWeight.bold,
                      color: AppTheme.bookmarkActiveColor,
                    ),
                  ),
                ),
              ),
              title: Text(
                bookmark.title,
                style: GoogleFonts.lora(
                  fontSize: 15,
                  fontWeight: FontWeight.w500,
                  color: fg,
                ),
              ),
              subtitle: Text(
                _formatDate(bookmark.createdAt),
                style: GoogleFonts.inter(
                  fontSize: 12,
                  color: subtextColor,
                ),
              ),
              trailing: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.bookmark_rounded, color: AppTheme.bookmarkActiveColor, size: 18),
                  const SizedBox(width: 8),
                  Icon(Icons.chevron_right_rounded, color: subtextColor, size: 20),
                ],
              ),
              onTap: () => widget.onJumpToPage(bookmark.pageNumber),
            ),
          ),
        ).animate().fadeIn(delay: (index * 50).ms).slideX(begin: 0.05, end: 0);
      },
    );
  }

  String _formatDate(DateTime dt) {
    final now = DateTime.now();
    final diff = now.difference(dt);
    if (diff.inMinutes < 1) return 'Just now';
    if (diff.inHours < 1) return '${diff.inMinutes}m ago';
    if (diff.inDays < 1) return '${diff.inHours}h ago';
    if (diff.inDays < 7) return '${diff.inDays}d ago';
    return '${dt.day}/${dt.month}/${dt.year}';
  }
}
