import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:syncfusion_flutter_pdfviewer/pdfviewer.dart';

class SearchDialog extends StatefulWidget {
  final GlobalKey<SfPdfViewerState> pdfViewerKey;

  const SearchDialog({super.key, required this.pdfViewerKey});

  @override
  State<SearchDialog> createState() => _SearchDialogState();
}

class _SearchDialogState extends State<SearchDialog> {
  final TextEditingController _controller = TextEditingController();
  PdfTextSearchResult? _searchResult;
  bool _isSearching = false;
  String _statusText = '';

  @override
  void dispose() {
    _controller.dispose();
    _searchResult?.clear();
    super.dispose();
  }

  Future<void> _search() async {
    final query = _controller.text.trim();
    if (query.isEmpty) return;

    setState(() {
      _isSearching = true;
      _statusText = 'Searching...';
    });

    _searchResult?.clear();
    _searchResult = await widget.pdfViewerKey.currentState?.findText(query);

    if (!mounted) return;
    setState(() {
      _isSearching = false;
      if (_searchResult != null && _searchResult!.totalInstanceCount > 0) {
        _statusText =
            'Found ${_searchResult!.totalInstanceCount} result(s) — Instance 1';
      } else {
        _statusText = 'No results found for "$query"';
      }
    });
  }

  void _nextResult() {
    _searchResult?.nextInstance();
    final current = _searchResult?.currentInstanceIndex ?? 0;
    final total = _searchResult?.totalInstanceCount ?? 0;
    setState(() {
      _statusText =
          'Found $total result(s) — Instance $current';
    });
  }

  void _prevResult() {
    _searchResult?.previousInstance();
    final current = _searchResult?.currentInstanceIndex ?? 0;
    final total = _searchResult?.totalInstanceCount ?? 0;
    setState(() {
      _statusText =
          'Found $total result(s) — Instance $current';
    });
  }

  void _clear() {
    _searchResult?.clear();
    _searchResult = null;
    _controller.clear();
    setState(() {
      _statusText = '';
    });
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;
    final bgColor = isDark ? const Color(0xFF1A1A2E) : Colors.white;
    final fg = isDark ? const Color(0xFFE8E8F0) : const Color(0xFF1A1A2E);
    final accentColor = isDark ? const Color(0xFFBB86FC) : const Color(0xFF8E44AD);
    final hasResults =
        _searchResult != null && _searchResult!.totalInstanceCount > 0;

    return Dialog(
      backgroundColor: bgColor,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(Icons.search_rounded, color: accentColor, size: 22),
                const SizedBox(width: 10),
                Text(
                  'Search in Book',
                  style: GoogleFonts.playfairDisplay(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: fg,
                  ),
                ),
                const Spacer(),
                GestureDetector(
                  onTap: () => Navigator.pop(context),
                  child: Icon(Icons.close_rounded, color: fg.withOpacity(0.5), size: 22),
                ),
              ],
            ),
            const SizedBox(height: 16),
            TextField(
              controller: _controller,
              autofocus: true,
              style: GoogleFonts.lora(fontSize: 15, color: fg),
              decoration: InputDecoration(
                hintText: 'Enter search term...',
                hintStyle: GoogleFonts.lora(
                  fontSize: 15,
                  color: fg.withOpacity(0.4),
                  fontStyle: FontStyle.italic,
                ),
                filled: true,
                fillColor: isDark
                    ? const Color(0xFF0D0D1A)
                    : const Color(0xFFF8F5F0),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: BorderSide.none,
                ),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: BorderSide(color: accentColor, width: 1.5),
                ),
                contentPadding: const EdgeInsets.symmetric(
                  horizontal: 16,
                  vertical: 12,
                ),
                suffixIcon: _controller.text.isNotEmpty
                    ? GestureDetector(
                        onTap: _clear,
                        child: Icon(Icons.clear_rounded,
                            color: fg.withOpacity(0.4), size: 18),
                      )
                    : null,
              ),
              onSubmitted: (_) => _search(),
              onChanged: (_) => setState(() {}),
            ),
            const SizedBox(height: 12),

            // Status
            if (_statusText.isNotEmpty)
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                decoration: BoxDecoration(
                  color: hasResults
                      ? accentColor.withOpacity(0.1)
                      : Colors.red.withOpacity(0.08),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Text(
                  _statusText,
                  style: GoogleFonts.inter(
                    fontSize: 12,
                    color: hasResults ? accentColor : Colors.red,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ),

            const SizedBox(height: 16),

            // Buttons
            Row(
              children: [
                if (hasResults) ...[
                  _SearchNavBtn(
                    icon: Icons.arrow_upward_rounded,
                    onTap: _prevResult,
                    color: accentColor,
                  ),
                  const SizedBox(width: 8),
                  _SearchNavBtn(
                    icon: Icons.arrow_downward_rounded,
                    onTap: _nextResult,
                    color: accentColor,
                  ),
                  const SizedBox(width: 8),
                ],
                const Spacer(),
                TextButton(
                  onPressed: () => Navigator.pop(context),
                  child: Text('Close',
                      style: GoogleFonts.inter(color: fg.withOpacity(0.5))),
                ),
                const SizedBox(width: 8),
                ElevatedButton(
                  onPressed: _isSearching ? null : _search,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: accentColor,
                    foregroundColor: Colors.white,
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10)),
                    padding: const EdgeInsets.symmetric(
                        horizontal: 20, vertical: 10),
                  ),
                  child: _isSearching
                      ? const SizedBox(
                          width: 16,
                          height: 16,
                          child: CircularProgressIndicator(
                            color: Colors.white,
                            strokeWidth: 2,
                          ),
                        )
                      : Text('Search',
                          style: GoogleFonts.inter(fontWeight: FontWeight.w600)),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _SearchNavBtn extends StatelessWidget {
  final IconData icon;
  final VoidCallback onTap;
  final Color color;

  const _SearchNavBtn(
      {required this.icon, required this.onTap, required this.color});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 36,
        height: 36,
        decoration: BoxDecoration(
          color: color.withOpacity(0.1),
          borderRadius: BorderRadius.circular(8),
          border: Border.all(color: color.withOpacity(0.2)),
        ),
        child: Icon(icon, color: color, size: 18),
      ),
    );
  }
}
