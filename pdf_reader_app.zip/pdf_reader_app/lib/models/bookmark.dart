class Bookmark {
  final int pageNumber;
  final String title;
  final DateTime createdAt;
  final String? note;

  const Bookmark({
    required this.pageNumber,
    required this.title,
    required this.createdAt,
    this.note,
  });

  Map<String, dynamic> toJson() => {
        'pageNumber': pageNumber,
        'title': title,
        'createdAt': createdAt.toIso8601String(),
        'note': note,
      };

  factory Bookmark.fromJson(Map<String, dynamic> json) => Bookmark(
        pageNumber: json['pageNumber'] as int,
        title: json['title'] as String,
        createdAt: DateTime.parse(json['createdAt'] as String),
        note: json['note'] as String?,
      );

  Bookmark copyWith({
    int? pageNumber,
    String? title,
    DateTime? createdAt,
    String? note,
  }) {
    return Bookmark(
      pageNumber: pageNumber ?? this.pageNumber,
      title: title ?? this.title,
      createdAt: createdAt ?? this.createdAt,
      note: note ?? this.note,
    );
  }

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is Bookmark &&
          runtimeType == other.runtimeType &&
          pageNumber == other.pageNumber;

  @override
  int get hashCode => pageNumber.hashCode;
}
