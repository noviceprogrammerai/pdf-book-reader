import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/bookmark.dart';

class StorageService {
  static const String _lastPageKey = 'last_read_page';
  static const String _totalPagesKey = 'total_pages';
  static const String _bookmarksKey = 'bookmarks';
  static const String _darkModeKey = 'dark_mode';
  static const String _fontSizeKey = 'font_size';

  final SharedPreferences _prefs;

  StorageService(this._prefs);

  // ── Reading Progress ──────────────────────────────────────────────────────

  int getLastPage() => _prefs.getInt(_lastPageKey) ?? 0;

  Future<void> saveLastPage(int page) =>
      _prefs.setInt(_lastPageKey, page);

  int getTotalPages() => _prefs.getInt(_totalPagesKey) ?? 0;

  Future<void> saveTotalPages(int total) =>
      _prefs.setInt(_totalPagesKey, total);

  double getReadingProgress() {
    final total = getTotalPages();
    if (total == 0) return 0.0;
    return getLastPage() / total;
  }

  Future<void> resetProgress() async {
    await _prefs.remove(_lastPageKey);
    await _prefs.remove(_totalPagesKey);
  }

  // ── Bookmarks ─────────────────────────────────────────────────────────────

  List<Bookmark> getBookmarks() {
    final raw = _prefs.getStringList(_bookmarksKey) ?? [];
    return raw
        .map((s) => Bookmark.fromJson(jsonDecode(s) as Map<String, dynamic>))
        .toList()
      ..sort((a, b) => a.pageNumber.compareTo(b.pageNumber));
  }

  bool isPageBookmarked(int page) {
    return getBookmarks().any((b) => b.pageNumber == page);
  }

  Future<void> addBookmark(Bookmark bookmark) async {
    final list = getBookmarks();
    // Remove existing bookmark for same page if any
    list.removeWhere((b) => b.pageNumber == bookmark.pageNumber);
    list.add(bookmark);
    await _saveBookmarks(list);
  }

  Future<void> removeBookmark(int pageNumber) async {
    final list = getBookmarks();
    list.removeWhere((b) => b.pageNumber == pageNumber);
    await _saveBookmarks(list);
  }

  Future<void> toggleBookmark(int pageNumber, String title) async {
    if (isPageBookmarked(pageNumber)) {
      await removeBookmark(pageNumber);
    } else {
      await addBookmark(Bookmark(
        pageNumber: pageNumber,
        title: title,
        createdAt: DateTime.now(),
      ));
    }
  }

  Future<void> clearAllBookmarks() async {
    await _prefs.remove(_bookmarksKey);
  }

  Future<void> _saveBookmarks(List<Bookmark> bookmarks) async {
    final raw = bookmarks.map((b) => jsonEncode(b.toJson())).toList();
    await _prefs.setStringList(_bookmarksKey, raw);
  }

  // ── Settings ──────────────────────────────────────────────────────────────

  bool getDarkMode() => _prefs.getBool(_darkModeKey) ?? false;

  Future<void> saveDarkMode(bool value) =>
      _prefs.setBool(_darkModeKey, value);

  double getFontScale() => _prefs.getDouble(_fontSizeKey) ?? 1.0;

  Future<void> saveFontScale(double value) =>
      _prefs.setDouble(_fontSizeKey, value);

  // ── Full Reset ────────────────────────────────────────────────────────────

  Future<void> resetAll() async {
    await resetProgress();
    await clearAllBookmarks();
  }
}
