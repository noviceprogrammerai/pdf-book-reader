# 📖 PDF Reader App — Flutter

A feature-rich, offline-first digital book reader app built with Flutter. Ships with a preloaded PDF ("The Art of Deep Focus") bundled in the app assets. Users cannot add external PDFs — the experience is focused entirely on this one built-in book.

---

## ✨ Features

| Feature | Details |
|---|---|
| **PDF Viewer** | Syncfusion PDF viewer — smooth rendering, zoom, scroll |
| **Scroll Modes** | Vertical continuous OR horizontal page-flip (toggle in top bar) |
| **Bookmarks** | Add/remove/list bookmarks, tap to jump to page |
| **Progress Tracking** | Auto-saves last read page, resumes on reopen |
| **Search** | Full-text search inside the PDF |
| **Page Jump** | Tap progress % to jump to any page |
| **Dark / Light Mode** | Kindle-style toggle, persisted across sessions |
| **Navigation Drawer** | Read Book / Bookmarks / Settings |
| **Settings Page** | Reset progress, clear bookmarks, toggle theme |
| **Offline** | 100% offline — PDF is bundled in assets |
| **Animations** | flutter_animate — splash, list, drawer transitions |

---

## 📁 Project Structure

```
pdf_reader_app/
├── lib/
│   ├── main.dart                  # Entry point, theme wiring
│   ├── theme/
│   │   └── app_theme.dart         # Light + dark ThemeData, colors, typography
│   ├── models/
│   │   └── bookmark.dart          # Bookmark data model + JSON serialisation
│   ├── services/
│   │   └── storage_service.dart   # SharedPreferences wrapper (progress + bookmarks)
│   ├── screens/
│   │   ├── splash_screen.dart     # Animated launch screen
│   │   ├── home_screen.dart       # Scaffold + navigation drawer
│   │   ├── reader_screen.dart     # Core PDF viewer screen
│   │   ├── bookmarks_screen.dart  # Bookmarks list (swipe-to-delete)
│   │   └── settings_screen.dart   # Settings + stats
│   └── widgets/
│       ├── search_dialog.dart     # PDF full-text search dialog
│       └── page_jump_dialog.dart  # "Go to page" dialog
├── assets/
│   └── pdf/
│       └── book.pdf               # ← Bundled PDF (replace with your own)
├── android/                       # Android project files
├── ios/                           # iOS project files
├── pubspec.yaml
└── README.md
```

---

## 🚀 Setup & Build Instructions

### Prerequisites

Make sure your Flutter environment is ready (this project targets your exact setup):

```
Flutter 3.41.7 (stable)
Dart 3.11.5
Android SDK 36.1.0 / Java 21 (OpenJDK)
```

---

### Step 1 — Clone / Extract the project

```bash
# If you're extracting the ZIP:
unzip pdf_reader_app.zip -d D:\projects\
cd D:\projects\pdf_reader_app
```

---

### Step 2 — Install dependencies

```bash
flutter pub get
```

---

### Step 3 — Replace the bundled PDF (optional)

Drop your own PDF into:

```
assets/pdf/book.pdf
```

> ⚠️ The filename **must** remain `book.pdf`, or update the asset path in:
> - `pubspec.yaml` → `assets:` section
> - `lib/screens/reader_screen.dart` → `SfPdfViewer.asset('assets/pdf/book.pdf', ...)`
> - `lib/screens/home_screen.dart` → drawer book title text

---

### Step 4 — Run on Android

```bash
# Start your emulator first (or connect a device), then:
flutter run
```

To build a release APK:

```bash
flutter build apk --release
# Output: build/app/outputs/flutter-apk/app-release.apk
```

To build an App Bundle (for Play Store):

```bash
flutter build appbundle --release
```

---

### Step 5 — Run on iOS (macOS only)

```bash
cd ios && pod install && cd ..
flutter run
```

To build for device:

```bash
flutter build ios --release
```

> You need Xcode + Apple Developer account for device/IPA builds.

---

### Step 6 — Run on Windows (for testing)

```bash
flutter run -d windows
```

---

## 🎨 Changing the Book Title

The book title "The Art of Deep Focus" is hardcoded in two places:

1. `lib/screens/reader_screen.dart` → AppBar title string
2. `lib/screens/home_screen.dart` → Drawer header title + author

Update both to match your PDF's title.

---

## 📦 Dependencies

| Package | Purpose |
|---|---|
| `syncfusion_flutter_pdfviewer` | PDF rendering, search, zoom, scroll |
| `syncfusion_flutter_pdf` | PDF document utilities |
| `shared_preferences` | Local storage for progress & bookmarks |
| `flutter_animate` | Animations (splash, list, transitions) |
| `google_fonts` | Playfair Display + Lora typography |

> **Syncfusion Free License**: The Syncfusion packages are free for individual developers and small businesses (revenue < $1M USD). Register at https://www.syncfusion.com/products/communitylicense for a free community license key if required.

---

## 🗂️ Data Storage

All user data is stored locally on-device using `SharedPreferences`:

| Key | Type | Description |
|---|---|---|
| `last_read_page` | int | Last viewed page number |
| `total_pages` | int | Total pages (set on first load) |
| `bookmarks` | List\<String\> | JSON-encoded list of Bookmark objects |
| `dark_mode` | bool | Theme preference |
| `font_size` | double | Font scale (reserved for future use) |

---

## 🛠️ Troubleshooting

**"Gradle build failed"**
```bash
cd android
./gradlew clean
cd ..
flutter clean && flutter pub get && flutter run
```

**"Unable to load asset: assets/pdf/book.pdf"**
- Check `pubspec.yaml` has the asset listed under `flutter: assets:`
- Make sure the file exists at `assets/pdf/book.pdf`
- Run `flutter pub get` after any pubspec changes

**Syncfusion watermark on PDF**
- The community license is free — register at syncfusion.com/products/communitylicense
- Add your license key in `main.dart` before `runApp()`:
```dart
import 'package:syncfusion_flutter_core/theme.dart';
SyncfusionLicense.registerLicense('YOUR_LICENSE_KEY');
```

**Dark mode not persisting**
- SharedPreferences initializes async in `main()` — ensure you await it before `runApp()`

---

## 📱 Supported Platforms

| Platform | Status |
|---|---|
| Android (API 21+) | ✅ Full support |
| iOS (13+) | ✅ Full support |
| Windows | ✅ Works (for development/testing) |
| Web | ⚠️ Limited (PDF viewer has web constraints) |

---

## 📄 License

MIT — free to use, modify, and distribute.

---

*Built with Flutter 3.41.7 • Syncfusion PDF • SharedPreferences*
